
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_FILE = path.join(__dirname, "..", "data", "sos.json");

const SEVERITIES = ["Low", "Medium", "High", "Critical"];
const STATUSES = ["Open", "In Progress", "Resolved"];

function ensureDataFile() {
  const directory = path.dirname(DATA_FILE);

  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }

  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, "[]", "utf8");
  }
}

function readIncidents() {
  ensureDataFile();

  const raw = fs.readFileSync(DATA_FILE, "utf8");
  const incidents = JSON.parse(raw || "[]");

  if (!Array.isArray(incidents)) {
    throw new Error("SOS data must be an array.");
  }

  return incidents;
}

function writeIncidents(incidents) {
  ensureDataFile();

  const tempFile =
    `${DATA_FILE}.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`;

  try {
    fs.writeFileSync(
      tempFile,
      JSON.stringify(incidents, null, 2),
      "utf8"
    );

    fs.renameSync(tempFile, DATA_FILE);
  } catch (error) {
    if (fs.existsSync(tempFile)) {
      fs.unlinkSync(tempFile);
    }

    throw error;
  }
}

function text(value, limit) {
  return typeof value === "string"
    ? value.trim().slice(0, limit)
    : "";
}

function createIncident(input) {
  const title = text(input.title, 120);
  const category = text(input.category, 80);
  const location = text(input.location, 200);
  const reportedBy = text(input.reportedBy, 100);
  const description = text(input.description, 2000);
  const severity = text(input.severity, 20);

  if (
    !title ||
    !category ||
    !location ||
    !reportedBy ||
    !description
  ) {
    throw new Error(
      "Title, category, location, reporter and description are required."
    );
  }

  if (!SEVERITIES.includes(severity)) {
    throw new Error("Invalid SOS severity.");
  }

  const incidents = readIncidents();
  const now = new Date().toISOString();

  const incident = {
    id: `PG-${Date.now().toString(36).toUpperCase()}-${crypto
      .randomBytes(3)
      .toString("hex")
      .toUpperCase()}`,
    title,
    category,
    location,
    reportedBy,
    description,
    severity,
    status: "Open",
    createdAt: now,
    updatedAt: now,
    history: [
      {
        status: "Open",
        at: now,
        note: "Incident reported"
      }
    ]
  };

  incidents.push(incident);
  writeIncidents(incidents);

  return incident;
}

function createAutoIncident(input) {
  const title = text(input.title, 120);
  const location = text(input.location, 200);
  const description = text(input.description, 2000);
  const severity = text(input.severity, 20);

  const incidents = readIncidents();

  // Prevent repeated analysis from creating duplicate active AI alerts.
  const existing = incidents.find((incident) => {
    return (
      incident.category === "AI Disruption Detection" &&
      incident.title === title &&
      incident.location === location &&
      incident.description === description &&
      ["Open", "In Progress"].includes(incident.status)
    );
  });

  if (existing) {
    // Upgrade severity when a repeated detection is more serious.
    const rank = {
      Low: 1,
      Medium: 2,
      High: 3,
      Critical: 4
    };

    if (
      rank[severity] > rank[existing.severity]
    ) {
      const now = new Date().toISOString();

      existing.severity = severity;
      existing.updatedAt = now;
      existing.history = Array.isArray(existing.history)
        ? existing.history
        : [];

      existing.history.push({
        status: existing.status,
        at: now,
        note: `AI detection severity upgraded to ${severity}`
      });

      writeIncidents(incidents);
    }

    return {
      incident: existing,
      created: false
    };
  }

  const incident = createIncident({
    title,
    category: "AI Disruption Detection",
    location,
    reportedBy: "PharmaGuard AI Detection Agent",
    description,
    severity
  });

  return {
    incident,
    created: true
  };
}

function updateIncidentStatus(id, status, note = "") {
  if (!STATUSES.includes(status)) {
    throw new Error("Invalid incident status.");
  }

  const incidents = readIncidents();
  const incident = incidents.find((item) => item.id === id);

  if (!incident) {
    return null;
  }

  const now = new Date().toISOString();

  incident.status = status;
  incident.updatedAt = now;
  incident.history = Array.isArray(incident.history)
    ? incident.history
    : [];

  incident.history.push({
    status,
    at: now,
    note: text(note, 300) || `Status changed to ${status}`
  });

  writeIncidents(incidents);

  return incident;
}

module.exports = {
  readIncidents,
  createIncident,
  createAutoIncident,
  updateIncidentStatus
};
