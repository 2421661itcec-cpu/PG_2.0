const express = require("express");

const router = express.Router();

const {
  createRecoveryPlan,
  executeApprovedRecovery
} = require("../agents/pharmaGuardOrchestrator");

const {
  createAutoIncident
} = require("../services/sosService");

/**
 * Broadcast the completed analysis to connected PharmaGuard dashboards.
 * This is separate from SOS incident creation: every severity can produce
 * an analysis notification, while only HIGH/CRITICAL create automatic SOS.
 */
function emitDisruptionAnalysis(req, result, inputDescription) {
  try {
    const io = req.app.get("io");
    const disruption = result?.disruption || {};
    const impact = result?.impact || {};

    const severity = String(
      disruption.severity || impact.overall_impact || "UNKNOWN"
    ).trim().toUpperCase();

    const description = String(
      disruption.disruption ||
      disruption.description ||
      inputDescription ||
      "Supply chain disruption"
    ).trim();

    const payload = {
      analysisId: `analysis-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      severity,
      title: `${severity} DISRUPTION DETECTED`,
      description,
      location: String(
        disruption.disrupted_location ||
        disruption.location ||
        "Location not specified"
      ).trim(),
      affectedShipmentCount:
        impact.affected_shipment_count ??
        (Array.isArray(impact.affected_shipments) ? impact.affected_shipments.length : 0),
      timestamp: new Date().toISOString()
    };

    if (io && typeof io.emit === "function") {
      io.emit("disruption:analyzed", payload);
      console.log(`[Disruption Notifications] Emitted ${severity} analysis notification.`);
    } else {
      console.warn("[Disruption Notifications] Socket.IO instance unavailable; analysis response still returned.");
    }
  } catch (error) {
    // Notification failures must never break analysis or recovery planning.
    console.error("[Disruption Notifications] Could not emit analysis event:", error.message);
  }
}

function recordHighSeverityDisruption(result) {
  try {
    const disruption = result?.disruption || {};
    const rawSeverity = String(
      disruption.severity || ""
    ).trim().toUpperCase();

    // Preserve existing behavior: only HIGH and CRITICAL create automatic SOS.
    if (!["HIGH", "CRITICAL"].includes(rawSeverity)) {
      return;
    }

    const severity =
      rawSeverity === "CRITICAL"
        ? "Critical"
        : "High";

    const description = String(
      disruption.disruption ||
      disruption.description ||
      ""
    ).trim();

    if (!description) {
      console.warn(
        "[SOS] Skipping automatic alert: disruption description is empty."
      );
      return;
    }

    const location = String(
      disruption.disrupted_location ||
      "Unknown location"
    ).trim();

    const saved = createAutoIncident({
      title: description,
      location,
      description,
      severity
    });

    console.log(
      saved.created
        ? `[SOS] Created ${severity} incident ${saved.incident.id}`
        : `[SOS] Reused active incident ${saved.incident.id}`
    );
  } catch (error) {
    // SOS logging must never interrupt the recovery analysis response.
    console.error(
      "[SOS] Automatic incident logging failed:",
      error.message
    );
  }
}


// --------------------------------------------------
// STEP 1: CREATE RECOVERY PLAN / ANALYZE DISRUPTION
// --------------------------------------------------

router.post("/recovery", (req, res) => {
  const { disruption } = req.body || {};

  if (
    typeof disruption !== "string" ||
    !disruption.trim()
  ) {
    return res.status(400).json({
      success: false,
      status: "INVALID_REQUEST",
      message: "Disruption description is required."
    });
  }

  try {
    const result = createRecoveryPlan(disruption);

    // Broadcast every completed analysis with its returned severity.
    emitDisruptionAnalysis(req, result, disruption);

    // Keep automatic SOS creation restricted to HIGH and CRITICAL.
    recordHighSeverityDisruption(result);

    return res.json(result);
  } catch (error) {
    console.error(
      "[PharmaGuard] Recovery plan creation failed:",
      error
    );

    return res.status(500).json({
      success: false,
      status: "RECOVERY_PLAN_FAILED",
      message: "Could not generate the recovery plan."
    });
  }
});


// --------------------------------------------------
// STEP 2: EXECUTE APPROVED RECOVERY
// --------------------------------------------------

router.post("/recovery/execute", (req, res) => {
  const { approval } = req.body || {};

  if (!approval) {
    return res.status(400).json({
      success: false,
      status: "INVALID_REQUEST",
      message: "Approval result is required."
    });
  }

  try {
    const result = executeApprovedRecovery(approval);

    if (!result.success) {
      return res.status(403).json(result);
    }

    return res.json(result);
  } catch (error) {
    console.error(
      "[PharmaGuard] Recovery execution failed:",
      error
    );

    return res.status(500).json({
      success: false,
      status: "RECOVERY_EXECUTION_FAILED",
      message: "Could not execute the approved recovery plan."
    });
  }
});

module.exports = router;
