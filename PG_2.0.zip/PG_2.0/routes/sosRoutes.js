const express = require("express");
const router = express.Router();

const {
  readIncidents,
  createIncident,
  updateIncidentStatus
} = require("../services/sosService");

function text(value, limit) {
  return typeof value === "string" ? value.trim().slice(0, limit) : "";
}

function handleError(res, error) {
  console.error("[SOS]", error.message);
  return res.status(500).json({
    success: false,
    error: "SOS storage operation failed. Check server logs."
  });
}

function emitSOS(req, eventName, incident) {
  const io = req.app.get("io");
  if (!io) {
    console.error(`[SOS] Socket.IO unavailable; could not emit ${eventName}.`);
    return false;
  }

  io.emit(eventName, incident);
  console.log(`[SOS] Emitted ${eventName} for ${incident.id}`);
  return true;
}

router.get("/", (req, res) => {
  try {
    const incidents = readIncidents().sort(
      (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
    );
    return res.json({ success: true, incidents });
  } catch (error) {
    return handleError(res, error);
  }
});

router.post("/", (req, res) => {
  const body = req.body || {};

  try {
    const incident = createIncident({
      title: text(body.title, 120),
      category: text(body.category, 80),
      location: text(body.location, 200),
      reportedBy: text(body.reportedBy, 100),
      description: text(body.description, 2000),
      severity: text(body.severity, 20)
    });

    // Emit only after createIncident has persisted the incident successfully.
    emitSOS(req, "sos:created", incident);

    return res.status(201).json({ success: true, incident });
  } catch (error) {
    if (error.message.includes("required") || error.message.includes("severity")) {
      return res.status(400).json({ success: false, error: error.message });
    }
    return handleError(res, error);
  }
});

router.patch("/:id/status", (req, res) => {
  const status = text(req.body?.status, 30);
  const note = text(req.body?.note, 300);
  const allowedStatuses = ["Open", "In Progress", "Resolved"];

  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ success: false, error: "Invalid incident status." });
  }

  try {
    const incident = updateIncidentStatus(req.params.id, status, note);
    if (!incident) {
      return res.status(404).json({ success: false, error: "Incident not found." });
    }

    emitSOS(req, "sos:updated", incident);
    return res.json({ success: true, incident });
  } catch (error) {
    return handleError(res, error);
  }
});

module.exports = router;
