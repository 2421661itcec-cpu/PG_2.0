const express = require("express");
const cors = require("cors");
const path = require("path");
const http = require("http");
const fs = require("fs");
const { Server } = require("socket.io");

const disruptionRoutes = require("./routes/disruptionRoutes");
const approvalRoutes = require("./routes/approvalRoutes");
const reroutingRoutes = require("./routes/reroutingRoutes");
const inventoryRoutes = require("./routes/inventoryRoutes");
const pharmaGuardRoutes = require("./routes/pharmaGuardRoutes");
const trackingRoutes = require("./routes/trackingRoutes");
const medicineRoutes = require("./routes/medicineRoutes");
const recoveryRoutes = require("./routes/recoveryRoutes");
const sosRoutes = require("./routes/sosRoutes");

const shipments = require("./data/shipments");
const inventory = require("./data/inventory");
const { startSimulation } = require("./data/gpsSimulator");

const app = express();
const PORT = process.env.PORT || 5050;
const HOST = "0.0.0.0";

// Ensure the SOS data file exists.
const dataDirectory = path.join(__dirname, "data");
const sosDataFile = path.join(dataDirectory, "sos.json");
fs.mkdirSync(dataDirectory, { recursive: true });
if (!fs.existsSync(sosDataFile)) {
  fs.writeFileSync(sosDataFile, "[]\n", "utf8");
}

// Middleware.
app.use(cors());
app.use(express.json({ limit: "100kb" }));

// Existing API routes — preserved.
app.use("/api/disruption", disruptionRoutes);
app.use("/api/approval", approvalRoutes);
app.use("/api/rerouting", reroutingRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/pharmaguard", pharmaGuardRoutes);
app.use("/api/tracking", trackingRoutes);
app.use("/api/medicines", medicineRoutes);
app.use("/api/recovery", recoveryRoutes);

// SOS routes. The router retrieves Socket.IO from req.app when requests arrive.
app.use("/api/sos", sosRoutes);

// Existing read-only data APIs — preserved.
app.get("/api/shipments", (req, res) => {
  res.json({ success: true, count: shipments.length, shipments });
});

app.get("/api/inventory/all", (req, res) => {
  res.json({ success: true, count: inventory.length, inventory });
});

// Frontend.
app.use(express.static(path.join(__dirname, "public")));

// Health check.
app.get("/api/health", (req, res) => {
  res.json({
    application: "PharmaGuard",
    status: "RUNNING",
    message: "PharmaGuard Backend Running",
    features: {
      sosEmergencyReporting: true,
      sosRealtimeNotifications: true,
      geospatialIntelligence: "Not integrated yet"
    }
  });
});

// Frontend fallback.
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// JSON error handler.
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);

  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({
      success: false,
      error: "Invalid JSON request body."
    });
  }

  console.error("[Server Error]", error.message);
  return res.status(500).json({ success: false, error: "Internal server error." });
});

// HTTP server + Socket.IO.
const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: { origin: "*", methods: ["GET", "POST", "PATCH"] }
});

// Expose Socket.IO to route handlers.
app.set("io", io);

io.on("connection", (socket) => {
  console.log(`[Socket.IO] Client connected: ${socket.id}`);

  socket.on("disconnect", () => {
    console.log(`[Socket.IO] Client disconnected: ${socket.id}`);
  });
});

httpServer.listen(PORT, HOST, () => {
  console.log(`PharmaGuard server running on ${HOST}:${PORT}`);
  console.log(`Dashboard: http://localhost:${PORT}`);
  console.log(`Health API: http://localhost:${PORT}/api/health`);
  console.log(`SOS API: http://localhost:${PORT}/api/sos`);

  try {
    startSimulation(io);
  } catch (error) {
    console.error("[GPS Simulator] Failed to start:", error.message);
  }
});
