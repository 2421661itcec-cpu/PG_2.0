
/*
 * PharmaGuard — SOS Emergency Reporting
 * File: public/sos.js
 *
 * Uses the existing Express API:
 *   GET   /api/sos
 *   POST  /api/sos
 *   PATCH /api/sos/:id/status
 *
 * This module is intentionally separate from app.js so the
 * existing recovery, inventory, shipment and map code remains intact.
 */

(() => {
  "use strict";

  const API_BASE = "/api/sos";
  let incidents = [];
  let isLoading = false;
  let refreshTimer = null;

  const $ = (id) => document.getElementById(id);

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function formatDate(value) {
    if (!value) return "Date unavailable";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return "Date unavailable";
    }

    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  async function request(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });

    let result;

    try {
      result = await response.json();
    } catch {
      throw new Error(
        `The server returned an unreadable response (${response.status}).`
      );
    }

    if (!response.ok) {
      throw new Error(
        result.message ||
        result.error ||
        `Request failed (${response.status}).`
      );
    }

    return result;
  }

  function notify(message) {
    const toast = $("toast");

    if (toast) {
      toast.textContent = message;
      toast.classList.remove("hidden");

      clearTimeout(window.pharmaGuardSosToastTimer);

      window.pharmaGuardSosToastTimer = setTimeout(() => {
        toast.classList.add("hidden");
      }, 3500);
    } else {
      alert(message);
    }
  }

  function injectStyles() {
    if ($("pharmaGuardSosStyles")) return;

    const style = document.createElement("style");
    style.id = "pharmaGuardSosStyles";

    style.textContent = `
      #sosView {
        width: 100%;
        min-width: 0;
      }

      .sos-page-heading {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 16px;
        margin-bottom: 22px;
      }

      .sos-page-heading h2 {
        margin: 5px 0 7px;
        color: #172033;
        font-size: 25px;
      }

      .sos-page-heading p {
        color: #64748b;
        font-size: 13px;
        line-height: 1.6;
        max-width: 680px;
      }

      .sos-live-pill {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: 1px solid #bbf7d0;
        background: #f0fdf4;
        color: #166534;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 800;
        white-space: nowrap;
      }

      .sos-live-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #16a34a;
      }

      .sos-summary-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 20px;
      }

      .sos-summary-card {
        padding: 18px;
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        min-width: 0;
      }

      .sos-summary-label {
        color: #64748b;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: .07em;
        text-transform: uppercase;
      }

      .sos-summary-value {
        display: block;
        color: #172033;
        font-size: 28px;
        font-weight: 850;
        margin-top: 7px;
      }

      .sos-layout {
        display: grid;
        grid-template-columns: minmax(280px, .85fr) minmax(0, 1.4fr);
        gap: 18px;
        align-items: start;
      }

      .sos-panel {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 13px;
        padding: 22px;
        min-width: 0;
      }

      .sos-panel-heading {
        margin-bottom: 18px;
      }

      .sos-panel-heading h3 {
        color: #172033;
        font-size: 17px;
        margin-bottom: 5px;
      }

      .sos-panel-heading p {
        color: #64748b;
        font-size: 12px;
        line-height: 1.5;
      }

      .sos-form {
        display: grid;
        gap: 14px;
      }

      .sos-field {
        display: grid;
        gap: 6px;
      }

      .sos-field label {
        color: #334155;
        font-size: 12px;
        font-weight: 750;
      }

      .sos-field input,
      .sos-field select,
      .sos-field textarea {
        width: 100%;
        min-width: 0;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        padding: 11px 12px;
        color: #172033;
        background: #ffffff;
        font: inherit;
        font-size: 13px;
        outline: none;
      }

      .sos-field textarea {
        min-height: 100px;
        resize: vertical;
      }

      .sos-field input:focus,
      .sos-field select:focus,
      .sos-field textarea:focus {
        border-color: #0f5bd3;
        box-shadow: 0 0 0 3px rgba(15, 91, 211, .1);
      }

      .sos-submit-button {
        width: 100%;
        border: 0;
        border-radius: 8px;
        background: #b91c1c;
        color: #ffffff;
        padding: 13px 16px;
        font-size: 13px;
        font-weight: 800;
        cursor: pointer;
        transition: background .2s ease;
      }

      .sos-submit-button:hover {
        background: #991b1b;
      }

      .sos-submit-button:disabled {
        opacity: .6;
        cursor: wait;
      }

      .sos-form-note {
        color: #64748b;
        font-size: 11px;
        line-height: 1.5;
      }

      .sos-list-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 14px;
      }

      .sos-list-toolbar h3 {
        color: #172033;
        font-size: 17px;
      }

      .sos-refresh-button {
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        background: #ffffff;
        color: #334155;
        padding: 8px 11px;
        font-size: 11px;
        font-weight: 750;
        cursor: pointer;
      }

      .sos-refresh-button:hover {
        border-color: #0f5bd3;
        color: #0f5bd3;
      }

      .sos-filter-row {
        display: flex;
        flex-wrap: wrap;
        gap: 7px;
        margin-bottom: 15px;
      }

      .sos-filter-button {
        border: 1px solid #e2e8f0;
        background: #f8fafc;
        color: #475569;
        border-radius: 999px;
        padding: 7px 11px;
        font-size: 10px;
        font-weight: 800;
        cursor: pointer;
      }

      .sos-filter-button.active {
        background: #172033;
        color: #ffffff;
        border-color: #172033;
      }

      .sos-incident-list {
        display: grid;
        gap: 12px;
      }

      .sos-incident-card {
        border: 1px solid #e2e8f0;
        border-left: 4px solid #64748b;
        border-radius: 10px;
        padding: 15px;
        background: #ffffff;
        min-width: 0;
      }

      .sos-incident-card.severity-critical {
        border-left-color: #b91c1c;
      }

      .sos-incident-card.severity-high {
        border-left-color: #ea580c;
      }

      .sos-incident-card.severity-medium {
        border-left-color: #d97706;
      }

      .sos-incident-card.severity-low {
        border-left-color: #0284c7;
      }

      .sos-incident-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 10px;
      }

      .sos-incident-id {
        color: #64748b;
        font-size: 10px;
        font-weight: 850;
        overflow-wrap: anywhere;
      }

      .sos-severity-tag,
      .sos-status-tag {
        display: inline-block;
        padding: 5px 8px;
        border-radius: 6px;
        font-size: 9px;
        font-weight: 900;
        text-transform: uppercase;
      }

      .sos-severity-tag.critical {
        color: #991b1b;
        background: #fee2e2;
      }

      .sos-severity-tag.high {
        color: #9a3412;
        background: #ffedd5;
      }

      .sos-severity-tag.medium {
        color: #92400e;
        background: #fef3c7;
      }

      .sos-severity-tag.low {
        color: #075985;
        background: #e0f2fe;
      }

      .sos-status-tag.open {
        color: #991b1b;
        background: #fee2e2;
      }

      .sos-status-tag.in-progress {
        color: #1d4ed8;
        background: #dbeafe;
      }

      .sos-status-tag.resolved {
        color: #166534;
        background: #dcfce7;
      }

      .sos-incident-card h4 {
        color: #172033;
        font-size: 15px;
        line-height: 1.45;
        overflow-wrap: anywhere;
        margin-bottom: 8px;
      }

      .sos-incident-meta {
        display: grid;
        gap: 6px;
        color: #475569;
        font-size: 11px;
        line-height: 1.5;
        margin-bottom: 10px;
      }

      .sos-incident-description {
        color: #334155;
        background: #f8fafc;
        border-radius: 7px;
        padding: 10px;
        font-size: 12px;
        line-height: 1.55;
        overflow-wrap: anywhere;
        white-space: pre-wrap;
      }

      .sos-incident-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
      }

      .sos-status-control {
        max-width: 190px;
        width: 100%;
        border: 1px solid #cbd5e1;
        background: #ffffff;
        color: #334155;
        border-radius: 7px;
        padding: 8px;
        font-size: 11px;
      }

      .sos-empty-state,
      .sos-error-state,
      .sos-loading-state {
        border: 1px dashed #cbd5e1;
        border-radius: 10px;
        padding: 25px 16px;
        color: #64748b;
        text-align: center;
        font-size: 12px;
        line-height: 1.6;
      }

      .sos-error-state {
        border-color: #fecaca;
        background: #fff7f7;
        color: #991b1b;
      }

      .sos-nav-count {
        margin-left: auto;
        min-width: 20px;
        text-align: center;
        border-radius: 999px;
        background: #b91c1c;
        color: #ffffff;
        font-size: 10px;
        font-weight: 900;
        padding: 3px 6px;
      }

      @media (max-width: 1050px) {
        .sos-layout {
          grid-template-columns: 1fr;
        }
      }

      @media (max-width: 800px) {
        .sos-summary-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .sos-panel {
          padding: 16px;
        }
      }

      @media (max-width: 420px) {
        .sos-summary-grid {
          grid-template-columns: 1fr 1fr;
          gap: 8px;
        }

        .sos-summary-card {
          padding: 13px;
        }

        .sos-summary-value {
          font-size: 23px;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function ensureNavigationButton() {
    const navigation = document.querySelector(".navigation");

    if (!navigation || $("navSOS")) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "nav-item";
    button.id = "navSOS";
    button.innerHTML = `
      <span aria-hidden="true">🚨</span>
      <span>SOS Incidents</span>
      <span class="sos-nav-count hidden" id="sosNavCount">0</span>
    `;

    const medicineButton = $("navMedicineMaster");

    if (medicineButton && medicineButton.parentElement === navigation) {
      medicineButton.insertAdjacentElement("afterend", button);
    } else {
      navigation.appendChild(button);
    }

    button.addEventListener("click", showSOSView);

    // Existing navigation handlers remain responsible for their views.
    document.querySelectorAll(".navigation .nav-item").forEach((item) => {
      if (item.id === "navSOS") return;

      item.addEventListener("click", () => {
        hideSOSView();
      });
    });
  }

  function ensureSOSView() {
    let view = $("sosView");

    if (view) return view;

    const main = document.querySelector(".main-content");

    if (!main) {
      console.error("PharmaGuard SOS: main content container was not found.");
      return null;
    }

    view = document.createElement("section");
    view.id = "sosView";
    view.style.display = "none";
    view.setAttribute("aria-labelledby", "sosPageTitle");

    view.innerHTML = `
      <div class="sos-page-heading">
        <div>
          <div class="section-kicker">IMPROVEMENT 1 · INCIDENT RESPONSE</div>
          <h2 id="sosPageTitle">SOS Emergency Reporting</h2>
          <p>
            Report supply-chain emergencies, record their severity and location,
            and track incident status through a persistent incident register.
          </p>
        </div>
        <div class="sos-live-pill">
          <span class="sos-live-dot"></span>
          SOS INCIDENT REGISTER
        </div>
      </div>

      <div class="sos-summary-grid" aria-live="polite">
        <article class="sos-summary-card">
          <span class="sos-summary-label">Total incidents</span>
          <strong class="sos-summary-value" id="sosTotalCount">0</strong>
        </article>
        <article class="sos-summary-card">
          <span class="sos-summary-label">Open</span>
          <strong class="sos-summary-value" id="sosOpenCount">0</strong>
        </article>
        <article class="sos-summary-card">
          <span class="sos-summary-label">In progress</span>
          <strong class="sos-summary-value" id="sosProgressCount">0</strong>
        </article>
        <article class="sos-summary-card">
          <span class="sos-summary-label">Critical / high</span>
          <strong class="sos-summary-value" id="sosUrgentCount">0</strong>
        </article>
      </div>

      <div class="sos-layout">
        <section class="sos-panel">
          <div class="sos-panel-heading">
            <h3>🚨 Report an emergency</h3>
            <p>Complete the incident details and submit them to the PharmaGuard server.</p>
          </div>

          <form id="sosReportForm" class="sos-form">
            <div class="sos-field">
              <label for="sosTitle">Incident title *</label>
              <input
                id="sosTitle"
                name="title"
                type="text"
                maxlength="140"
                placeholder="e.g. Medicine shipment blocked by flooding"
                required
              >
            </div>

            <div class="sos-field">
              <label for="sosCategory">Incident category *</label>
              <select id="sosCategory" name="category" required>
                <option value="">Select a category</option>
                <option value="Transport disruption">Transport disruption</option>
                <option value="Weather or natural disaster">Weather or natural disaster</option>
                <option value="Cold-chain failure">Cold-chain failure</option>
                <option value="Warehouse or facility issue">Warehouse or facility issue</option>
                <option value="Medicine shortage">Medicine shortage</option>
                <option value="Security incident">Security incident</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div class="sos-field">
              <label for="sosLocation">Location *</label>
              <input
                id="sosLocation"
                name="location"
                type="text"
                maxlength="180"
                placeholder="City, state, facility or route"
                required
              >
            </div>

            <div class="sos-field">
              <label for="sosReporter">Reported by *</label>
              <input
                id="sosReporter"
                name="reportedBy"
                type="text"
                maxlength="100"
                placeholder="Operator or team name"
                required
              >
            </div>

            <div class="sos-field">
              <label for="sosSeverity">Severity *</label>
              <select id="sosSeverity" name="severity" required>
                <option value="Critical">Critical — immediate threat</option>
                <option value="High" selected>High — urgent response</option>
                <option value="Medium">Medium — needs attention</option>
                <option value="Low">Low — routine follow-up</option>
              </select>
            </div>

            <div class="sos-field">
              <label for="sosDescription">Incident description *</label>
              <textarea
                id="sosDescription"
                name="description"
                maxlength="2000"
                placeholder="Describe what happened, the affected medicine or shipment, and the immediate risk."
                required
              ></textarea>
            </div>

            <button type="submit" class="sos-submit-button" id="sosSubmitButton">
              Submit SOS Incident
            </button>

            <p class="sos-form-note">
              Submissions are saved by the local PharmaGuard server. This prototype
              does not automatically contact emergency services or notify external responders.
            </p>
          </form>
        </section>

        <section class="sos-panel">
          <div class="sos-list-toolbar">
            <h3>Incident register</h3>
            <button type="button" class="sos-refresh-button" id="sosRefreshButton">
              ↻ Refresh
            </button>
          </div>

          <div class="sos-filter-row" role="group" aria-label="Filter incidents">
            <button type="button" class="sos-filter-button active" data-sos-filter="All">All</button>
            <button type="button" class="sos-filter-button" data-sos-filter="Open">Open</button>
            <button type="button" class="sos-filter-button" data-sos-filter="In Progress">In progress</button>
            <button type="button" class="sos-filter-button" data-sos-filter="Resolved">Resolved</button>
          </div>

          <div id="sosIncidentList" class="sos-incident-list" aria-live="polite">
            <div class="sos-loading-state">Loading saved incidents…</div>
          </div>
        </section>
      </div>
    `;

    const pageView = $("pageView");

    if (pageView && pageView.parentElement === main) {
      pageView.insertAdjacentElement("afterend", view);
    } else {
      main.appendChild(view);
    }

    $("sosReportForm").addEventListener("submit", submitIncident);
    $("sosRefreshButton").addEventListener("click", loadIncidents);

    view.querySelectorAll("[data-sos-filter]").forEach((button) => {
      button.addEventListener("click", () => {
        view.querySelectorAll("[data-sos-filter]").forEach((item) => {
          item.classList.toggle("active", item === button);
        });

        renderIncidents(button.dataset.sosFilter);
      });
    });

    return view;
  }

  function showSOSView() {
    const view = ensureSOSView();
    if (!view) return;

    const overview = $("overviewView");
    const commandCenter = $("commandCenterView");
    const pageView = $("pageView");

    if (overview) overview.style.display = "none";
    if (commandCenter) commandCenter.style.display = "none";
    if (pageView) pageView.style.display = "none";

    view.style.display = "block";

    document.querySelectorAll(".navigation .nav-item").forEach((item) => {
      item.classList.toggle("active", item.id === "navSOS");
    });

    const eyebrow = $("topbarEyebrow");
    const title = $("topbarTitle");
    const subtitle = $("topbarSubtitle");

    if (eyebrow) eyebrow.textContent = "EMERGENCY RESPONSE & INCIDENT TRACKING";
    if (title) title.textContent = "SOS Emergency Reporting";
    if (subtitle) subtitle.textContent = "Create, monitor and update supply-chain incidents";

    loadIncidents();

    clearInterval(refreshTimer);
    refreshTimer = setInterval(() => {
      if (view.style.display !== "none") {
        loadIncidents({ quiet: true });
      }
    }, 30000);
  }

  function hideSOSView() {
    const view = $("sosView");
    if (view) view.style.display = "none";

    clearInterval(refreshTimer);
    refreshTimer = null;
  }

  function updateSummary() {
    const open = incidents.filter((item) => item.status === "Open").length;
    const progress = incidents.filter((item) => item.status === "In Progress").length;
    const urgent = incidents.filter((item) =>
      ["Critical", "High"].includes(String(item.severity || "").trim())
    ).length;

    if ($("sosTotalCount")) $("sosTotalCount").textContent = incidents.length;
    if ($("sosOpenCount")) $("sosOpenCount").textContent = open;
    if ($("sosProgressCount")) $("sosProgressCount").textContent = progress;
    if ($("sosUrgentCount")) $("sosUrgentCount").textContent = urgent;

    const countBadge = $("sosNavCount");

    if (countBadge) {
      countBadge.textContent = open + progress;
      countBadge.classList.toggle("hidden", open + progress === 0);
    }
  }

  function statusClass(status) {
    if (status === "In Progress") return "in-progress";
    if (status === "Resolved") return "resolved";
    return "open";
  }

  function severityClass(severity) {
    const normalized = String(severity || "Medium").toLowerCase();
    return ["critical", "high", "medium", "low"].includes(normalized)
      ? normalized
      : "medium";
  }

  function renderIncidents(filter = null) {
    const container = $("sosIncidentList");
    if (!container) return;

    const activeFilter = filter ||
      document.querySelector("[data-sos-filter].active")?.dataset.sosFilter ||
      "All";

    const filtered = incidents.filter((incident) =>
      activeFilter === "All" || incident.status === activeFilter
    );

    updateSummary();

    if (!filtered.length) {
      container.innerHTML = `
        <div class="sos-empty-state">
          <strong>No incidents found.</strong><br>
          ${activeFilter === "All"
            ? "Submit the form to create your first SOS incident."
            : `There are currently no incidents with status "${escapeHtml(activeFilter)}".`}
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map((incident) => {
      const id = escapeHtml(incident.id);
      const severity = severityClass(incident.severity);
      const status = statusClass(incident.status);

      return `
        <article class="sos-incident-card severity-${severity}">
          <div class="sos-incident-top">
            <div class="sos-incident-id">${id}</div>
            <div>
              <span class="sos-severity-tag ${severity}">
                ${escapeHtml(incident.severity || "Medium")}
              </span>
              <span class="sos-status-tag ${status}">
                ${escapeHtml(incident.status || "Open")}
              </span>
            </div>
          </div>

          <h4>${escapeHtml(incident.title || "Untitled incident")}</h4>

          <div class="sos-incident-meta">
            <span>📍 <strong>Location:</strong> ${escapeHtml(incident.location || "Not provided")}</span>
            <span>🏷️ <strong>Category:</strong> ${escapeHtml(incident.category || "Other")}</span>
            <span>👤 <strong>Reported by:</strong> ${escapeHtml(incident.reportedBy || "Not provided")}</span>
            <span>🕒 <strong>Created:</strong> ${escapeHtml(formatDate(incident.createdAt))}</span>
            <span><strong>Last updated:</strong> ${escapeHtml(formatDate(incident.updatedAt || incident.createdAt))}</span>
          </div>

          <div class="sos-incident-description">${escapeHtml(incident.description || "No description provided.")}</div>

          <div class="sos-incident-footer">
            <span class="sos-form-note">Update the incident status:</span>
            <select
              class="sos-status-control"
              data-sos-id="${id}"
              aria-label="Update status for ${id}"
            >
              <option value="Open" ${incident.status === "Open" ? "selected" : ""}>Open</option>
              <option value="In Progress" ${incident.status === "In Progress" ? "selected" : ""}>In Progress</option>
              <option value="Resolved" ${incident.status === "Resolved" ? "selected" : ""}>Resolved</option>
            </select>
          </div>
        </article>
      `;
    }).join("");

    container.querySelectorAll("[data-sos-id]").forEach((select) => {
      select.addEventListener("change", async () => {
        const incidentId = select.dataset.sosId;
        const newStatus = select.value;

        select.disabled = true;

        try {
          await request(`${API_BASE}/${encodeURIComponent(incidentId)}/status`, {
            method: "PATCH",
            body: JSON.stringify({ status: newStatus })
          });

          notify(`Incident ${incidentId} updated to ${newStatus}.`);
          await loadIncidents({ quiet: true });
        } catch (error) {
          console.error("SOS status update failed:", error);
          notify(`Could not update incident: ${error.message}`);
          await loadIncidents({ quiet: true });
        } finally {
          select.disabled = false;
        }
      });
    });
  }

  async function loadIncidents(options = {}) {
    if (isLoading) return;

    const container = $("sosIncidentList");
    if (!container) return;

    isLoading = true;

    if (!options.quiet && incidents.length === 0) {
      container.innerHTML = `
        <div class="sos-loading-state">Loading saved incidents…</div>
      `;
    }

    try {
      const result = await request(API_BASE);

      if (Array.isArray(result)) {
        incidents = result;
      } else if (Array.isArray(result.incidents)) {
        incidents = result.incidents;
      } else if (Array.isArray(result.data)) {
        incidents = result.data;
      } else {
        incidents = [];
      }

      incidents.sort((a, b) => {
        return new Date(b.createdAt || 0).getTime() -
          new Date(a.createdAt || 0).getTime();
      });

      const activeFilter =
        document.querySelector("[data-sos-filter].active")?.dataset.sosFilter || "All";

      renderIncidents(activeFilter);
    } catch (error) {
      console.error("Unable to load SOS incidents:", error);

      if (!options.quiet) {
        container.innerHTML = `
          <div class="sos-error-state">
            <strong>Could not load SOS incidents.</strong><br>
            ${escapeHtml(error.message)}<br><br>
            Check that the PharmaGuard server is running and the /api/sos route is available.
          </div>
        `;
      }
    } finally {
      isLoading = false;
    }
  }

  async function submitIncident(event) {
    event.preventDefault();

    const form = $("sosReportForm");
    const submitButton = $("sosSubmitButton");

    if (!form || !submitButton) return;

    const formData = new FormData(form);

    const payload = {
      title: String(formData.get("title") || "").trim(),
      category: String(formData.get("category") || "").trim(),
      location: String(formData.get("location") || "").trim(),
      reportedBy: String(formData.get("reportedBy") || "").trim(),
      severity: String(formData.get("severity") || "Medium").trim(),
      description: String(formData.get("description") || "").trim()
    };

    const missing = Object.entries(payload).find(([, value]) => !value);

    if (missing) {
      notify("Please complete all required incident fields.");
      return;
    }

    submitButton.disabled = true;
    submitButton.textContent = "Submitting incident…";

    try {
      const result = await request(API_BASE, {
        method: "POST",
        body: JSON.stringify(payload)
      });

      form.reset();

      // Restore the default severity after reset.
      if ($("sosSeverity")) $("sosSeverity").value = "High";

      await loadIncidents({ quiet: true });

      const incidentId = result.incident?.id ||
        result.data?.id ||
        result.id ||
        "created";

      notify(`SOS incident submitted successfully. Reference: ${incidentId}`);

      const list = $("sosIncidentList");
      if (list) list.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (error) {
      console.error("SOS submission failed:", error);
      notify(`SOS submission failed: ${error.message}`);
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = "Submit SOS Incident";
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    injectStyles();
    ensureNavigationButton();
    ensureSOSView();

    console.log("PharmaGuard SOS module initialized.");
  });
})();
