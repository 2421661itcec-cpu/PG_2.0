/*
 * PharmaGuard SOS Notifications
 * Receives immediate Socket.IO events and retains polling as a fallback.
 * Alerts are shown for newly detected High and Critical incidents.
 */
(() => {
  "use strict";

  const API_URL = "/api/sos";
  const POLL_INTERVAL = 10000;
  const STORAGE_KEY = "pharmaguard_sos_notified_ids_v2";

  let initialized = false;
  let polling = false;
  let socket = null;
  const knownIncidentIds = new Set();
  const notifiedIncidentIds = new Set();

  function idOf(incident) {
    return String(incident?.id || incident?.incidentId || incident?._id || "");
  }
  function severityOf(incident) {
    return String(incident?.severity || "").trim().toLowerCase();
  }
  function worthy(incident) {
    return ["high", "critical"].includes(severityOf(incident));
  }
  function titleOf(incident) {
    return incident?.title || incident?.description || "SOS incident reported";
  }
  function locationOf(incident) {
    return incident?.location || incident?.region || "Location not specified";
  }

  function loadNotifiedIds() {
    try {
      const ids = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      if (Array.isArray(ids)) ids.forEach((id) => notifiedIncidentIds.add(String(id)));
    } catch (error) {
      console.warn("[SOS Notifications] Could not read notification history.", error);
    }
  }

  function saveNotifiedId(id) {
    try {
      notifiedIncidentIds.add(id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(notifiedIncidentIds).slice(-500)));
    } catch (error) {
      console.warn("[SOS Notifications] Could not save notification history.", error);
    }
  }

  function ensureUI() {
    if (document.getElementById("pg-sos-notification-tools")) return;

    const style = document.createElement("style");
    style.id = "pg-sos-notification-styles";
    style.textContent = `
      #pg-sos-notification-tools{position:fixed;right:18px;bottom:18px;z-index:99999;display:flex;flex-direction:column;align-items:flex-end;gap:10px;font-family:Arial,sans-serif;max-width:min(390px,calc(100vw - 36px))}
      #pg-sos-enable-notifications{border:1px solid #64748b;border-radius:9px;background:#172033;color:#fff;padding:11px 15px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 14px #0003}
      #pg-sos-toast-stack{display:flex;flex-direction:column;align-items:stretch;gap:8px;width:100%}
      .pg-sos-toast{border-radius:10px;padding:13px 15px;color:#fff;background:#7f1d1d;border-left:5px solid #ef4444;box-shadow:0 5px 20px #0005;font-size:13px;line-height:1.45;overflow-wrap:anywhere}
      .pg-sos-toast.pg-high{background:#78350f;border-left-color:#f59e0b}
      .pg-sos-toast strong{display:block;margin-bottom:4px}
      .pg-sos-toast button{margin-top:8px;border:1px solid #ffffff80;border-radius:6px;background:transparent;color:white;padding:5px 8px;cursor:pointer}
    `;
    document.head.appendChild(style);

    const tools = document.createElement("div");
    tools.id = "pg-sos-notification-tools";
    tools.innerHTML = `<div id="pg-sos-toast-stack" aria-live="assertive"></div><button id="pg-sos-enable-notifications" type="button">Enable SOS Notifications</button>`;
    document.body.appendChild(tools);
    document.getElementById("pg-sos-enable-notifications").addEventListener("click", enableNotifications);
    updatePermissionButton();
  }

  function updatePermissionButton() {
    const button = document.getElementById("pg-sos-enable-notifications");
    if (!button) return;
    if (!("Notification" in window)) {
      button.textContent = "In-app alerts active (desktop unavailable)";
      button.disabled = true;
    } else if (Notification.permission === "granted") {
      button.textContent = "✓ SOS Desktop Notifications Enabled";
      button.disabled = true;
    } else if (Notification.permission === "denied") {
      button.textContent = "Desktop notifications blocked — in-app alerts active";
      button.disabled = true;
    } else {
      button.textContent = "Enable SOS Desktop Notifications";
      button.disabled = false;
    }
  }

  async function enableNotifications() {
    if (!("Notification" in window)) {
      showToast("In-app alerts are active", "This browser does not support desktop notifications.", "high");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      updatePermissionButton();
      if (permission === "granted") {
        try {
          new Notification("PharmaGuard — Test Notification", {
            body: "Desktop notifications are enabled. In-app SOS alerts work separately."
          });
        } catch (error) {
          console.error("[SOS Notifications] Test notification failed.", error);
          showToast("Desktop notification failed", error.message || "Browser did not display the test notification.", "high");
        }
      } else {
        showToast("Desktop notifications not enabled", "In-app SOS alerts remain active while this dashboard is open.", "high");
      }
    } catch (error) {
      console.error("[SOS Notifications] Permission request failed.", error);
      showToast("Could not enable desktop notifications", error.message || "Check browser site permissions.", "high");
    }
  }

  function showToast(title, message, severity, incidentId = "") {
    const stack = document.getElementById("pg-sos-toast-stack");
    if (!stack) return;

    const toast = document.createElement("div");
    toast.className = "pg-sos-toast" + (severity === "high" ? " pg-high" : "");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const body = document.createElement("div");
    body.textContent = message;
    toast.append(heading, body);

    if (incidentId) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "View SOS incidents";
      button.addEventListener("click", () => {
        const nav = document.getElementById("navSOS");
        if (nav) nav.click();
        const view = document.getElementById("sosView");
        if (view) view.scrollIntoView({ behavior: "smooth", block: "start" });
        toast.remove();
      });
      toast.appendChild(button);
    }

    stack.appendChild(toast);
    while (stack.children.length > 4) stack.firstElementChild.remove();
    window.setTimeout(() => toast.remove(), 15000);
  }

  function notifyIncident(incident, source = "event") {
    const id = idOf(incident);
    if (!id || !worthy(incident) || notifiedIncidentIds.has(id)) return;
    const severity = severityOf(incident);
    const message = `${titleOf(incident)} | Location: ${locationOf(incident)} | Incident: ${id}`;

    // Always show the in-dashboard alert first; desktop permission is optional.
    showToast(`${severity.toUpperCase()} SOS INCIDENT`, message, severity, id);
    console.info(`[SOS Notifications] Alert displayed for ${id} (source: ${source}).`);

    if ("Notification" in window && Notification.permission === "granted") {
      try {
        const notification = new Notification(
          severity === "critical" ? "🚨 PharmaGuard — CRITICAL SOS" : "⚠️ PharmaGuard — HIGH SOS",
          { body: message, tag: `pharmaguard-sos-${id}` }
        );
        notification.onclick = () => {
          window.focus();
          const nav = document.getElementById("navSOS");
          if (nav) nav.click();
          notification.close();
        };
      } catch (error) {
        console.error("[SOS Notifications] Could not display desktop notification.", error);
      }
    }

    // Persist suppression only after attempting the visible alert.
    saveNotifiedId(id);
  }

  function extractIncidents(payload) {
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload?.incidents)) return payload.incidents;
    if (Array.isArray(payload?.data)) return payload.data;
    return [];
  }

  async function checkForIncidents() {
    if (polling) return;
    polling = true;
    try {
      const response = await fetch(API_URL, {
        headers: { Accept: "application/json" },
        cache: "no-store"
      });
      if (!response.ok) throw new Error(`SOS API returned HTTP ${response.status}`);
      const payload = await response.json();
      const incidents = extractIncidents(payload);

      if (!initialized) {
        incidents.forEach((incident) => {
          const id = idOf(incident);
          if (id) knownIncidentIds.add(id);
        });
        initialized = true;
        console.info(`[SOS Notifications] Monitoring started. Existing incidents: ${knownIncidentIds.size}`);
        return;
      }

      incidents.forEach((incident) => {
        const id = idOf(incident);
        if (!id || knownIncidentIds.has(id)) return;
        knownIncidentIds.add(id);
        notifyIncident(incident, "poll");
      });
    } catch (error) {
      console.error("[SOS Notifications] Could not check SOS incidents:", error);
    } finally {
      polling = false;
    }
  }

  // Same-tab disruption analysis alerts; does not depend on Socket.IO.
  window.addEventListener("pharmaguard:analysis-complete", (event) => {
    const analysis = event?.detail || {};
    const severity = String(analysis.severity || "UNKNOWN").trim().toUpperCase();
    const allowed = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
    const safeSeverity = allowed.includes(severity) ? severity : "UNKNOWN";
    const description = String(analysis.description || "Disruption analysis completed");
    const location = String(analysis.location || "Location not specified");
    const count = Number(analysis.affectedShipmentCount || 0);
    const message = `${description} | Location: ${location} | Affected shipments: ${count}`;

    showToast(`${safeSeverity} DISRUPTION ANALYSIS`, message, safeSeverity.toLowerCase());
    console.info(`[Disruption Notifications] ${safeSeverity} analysis alert displayed (source: local).`);

    if ("Notification" in window && Notification.permission === "granted") {
      try {
        const icon = safeSeverity === "CRITICAL" ? "🚨" :
          safeSeverity === "HIGH" ? "⚠️" :
          safeSeverity === "MEDIUM" ? "🔵" : "ℹ️";
        new Notification(`${icon} PharmaGuard — ${safeSeverity} DISRUPTION`, {
          body: message,
          tag: `pharmaguard-analysis-${analysis.analysisId || Date.now()}`
        });
      } catch (error) {
        console.error("[Disruption Notifications] Could not display desktop notification.", error);
      }
    }
  });

  function connectSocket() {
    if (typeof window.io !== "function") {
      console.warn("[SOS Notifications] Socket.IO client unavailable; polling fallback remains active.");
      return;
    }
    socket = window.io();
    socket.on("connect", () => console.info("[SOS Notifications] Socket connected:", socket.id));
    socket.on("connect_error", (error) => console.error("[SOS Notifications] Socket connection failed:", error.message));
    socket.on("sos:created", (incident) => {
      const id = idOf(incident);
      if (id) knownIncidentIds.add(id);
      console.info("[SOS Notifications] Received sos:created", incident);
      notifyIncident(incident, "socket");
    });
    socket.on("sos:updated", (incident) => {
      console.info("[SOS Notifications] Received sos:updated", idOf(incident));
    });
  }

  function start() {
    loadNotifiedIds();
    ensureUI();
    connectSocket();
    checkForIncidents();
    window.setInterval(checkForIncidents, POLL_INTERVAL);
    console.info("[SOS Notifications] Started (Socket.IO + polling fallback).");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
